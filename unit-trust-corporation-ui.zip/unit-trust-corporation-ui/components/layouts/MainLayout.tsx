import { FC } from 'react';
import Head from 'next/head';
import { Sidebar } from '../ui/Sidebar';
import { Navbar } from '../ui/Navbar';
import { Topbar } from '../ui/Topbar';

interface Props {
  title: string;
  pageDescription: string;
  imageFullUrl?: string;
  children: any
}

export const MainLayout: FC<Props> = ({ children, title, pageDescription, imageFullUrl }) => {
  return (
    <>

      <Head>
        <title>{title}</title>

        <meta name="description" content={pageDescription} />
        <meta name="og:title" content={title} />
        <meta name="og:description" content={pageDescription} />

        {/*
          imageFullUrl && (
            <meta name="og:image" content={imageFullUrl} />
          )*/
        }

      </Head>

      {/*<Page Wrapper />*/}
      <div id="wrapper">

        {/*<Navbar />*/}
        <Sidebar />


        {/*<Content Wrapper />*/}
        <div id="content-wrapper" className="d-flex flex-column">

          {/*<Main Content />*/}
          <div id="content" style={{ width: '100%' }}>

            <Topbar />

            {/*<Begin Page Content />*/}
            <div className="container-fluid">

              {/*<Page Heading />
              <div className="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 className="h3 mb-0 text-gray-800">Dashboard</h1>
                <a href="#" className="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i
                  className="fas fa-download fa-sm text-white-50"></i> Generate Report</a>
              </div>*/}

              <main>
                {children}
              </main>

            </div>
            {/*<container-fluid/>*/}

          </div>
          {/*<End of Main Content/>*/}



          {/*<Footer/>*/}
          <footer className="sticky-footer bg-white">
            <div className="container my-auto">
              <div className="copyright text-center my-auto">
                <span>Copyright &copy; Your Website 2021</span>
              </div>
            </div>
          </footer>
          {/*<End of Footer/>*/}


        </div>
        {/*<End of Content Wrapper/>*/}

      </div>
      {/*<End of Page Wrapper/>*/}
            
    </>
  )
}

