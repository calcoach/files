import { FC } from 'react';
import Head from 'next/head';
import { Sidebar } from '../ui/Sidebar';
import { Navbar } from '../ui/Navbar';
import { Topbar } from '../ui/Topbar';

interface Props {
  title: string;
  pageDescription: string;
  imageFullUrl?: string;
  children: any
}


export const AuthLayout: FC<Props> = ({ children, title, pageDescription, imageFullUrl }) => {
  return (

    <>

      <Head>
        <title>{title}</title>

        <meta name="description" content={pageDescription} />
        <meta name="og:title" content={title} />
        <meta name="og:description" content={pageDescription} />

        {<link rel="stylesheet" href="/css/auth-section.css" />}
        <link rel="stylesheet" href="/css/mdb.min.css" />

      </Head>

      <Navbar />

      <main className="mt-5">
        {children}
      </main>

    </>
  )
}

