
import Link from 'next/link';

export const Sidebar = () => {
  return (
    <>

      {/* Sidebar */}
      <ul className="navbar-nav bg-gradient-danger sidebar sidebar-dark accordion" id="accordionSidebar" >


        {/* Sidebar - Brand */}
        < a className="sidebar-brand d-flex align-items-center justify-content-center" href="index.html" >
          <div className="sidebar-brand-icon rotate-n-15">
            <i className="fas fa-laugh-wink"></i>
          </div>
          <div className="sidebar-brand-text mx-3">
            unit trust
            <br />
            corporation
          </div>
        </a >

        {/* Divider */}
        <hr className="sidebar-divider my-0" />

        {/* Divider */}
        < hr className="sidebar-divider" />

        {/* Nav Item - Segmentation */}
        < li className="nav-item" >
          <Link className="nav-link collapsed" href="/segmentation">
            <i className="fas fa-th-large"></i>
            <span>Segmentation</span>
          </Link>
        </li >

        {/* Nav Item - Balances */}
        < li className="nav-item" >
          <Link className="nav-link collapsed" href="/balances">
            <i className="fas fa-wallet"></i>
            <span>Balances</span>
          </Link>
        </li >

        {/* Nav Item - Transactions */}
        < li className="nav-item" >
          <Link className="nav-link collapsed" href="/transactions">
          <i className="fas fa-exchange-alt"></i>
            <span>Transactions</span>
          </Link>
        </li >

        {/* Nav Item - Trades */}
        < li className="nav-item" >
          <Link className="nav-link collapsed" href="/trades">
          <i className="fas fa-file-invoice-dollar"></i>
            <span>Trades</span>
          </Link>
        </li >

        {/* Nav Item - Expenses */}
        < li className="nav-item" >
          <Link className="nav-link collapsed" href="/expenses">
          <i className="fas fa-hand-holding-usd"></i>
            <span>Expenses</span>
          </Link>
        </li >

        {/* Nav Item - Goals */}
        < li className="nav-item" >
          <Link className="nav-link collapsed" href="/goals">
          <i className ="fas fa-bullseye"></i>
            <span>Goals</span>
          </Link>
        </li >

        {/* Nav Item - Settings */}
        < li className="nav-item" >
          <Link className="nav-link collapsed" href="/settings">
            <i className="fas fa-cog"></i>
            <span>Settings</span>
          </Link>
        </li >

        {/* Divider */}
        < hr className="sidebar-divider" />

        {/* Sidebar Toggler (Sidebar) */}
        < div className="text-center d-none d-md-inline" >
          <button className="rounded-circle border-0" id="sidebarToggle"></button>
        </div >

      </ul>
      {/* End of Sidebar */}
    </>
  )
}