"use client";
import "bootstrap/dist/css/bootstrap.min.css";
import { useState } from "react";
import { useEffect } from "react";

export const Demographic = () => {
  const [data, setData] = useState([]);
  const demodata = JSON.stringify(data.demograficRanges, null, 2)
  console.log(demodata)
const token = 'eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJqdWFuLnZpbGxhQGV4YW1wbGUuY29tIiwiaWF0IjoxNjg0ODQ4NDg1LCJzdWIiOiIkYXJnb24yaWQkdj0xOSRtPTEwMjQsdD0xLHA9MSQ0NTNFVUVPUHBGclYwQWQ2UXdpclJBJDNGVU10d3pGcDNmamdxTGhqVC9wcXk4a05vK0VMUTRWTFh5ck5jdFJwYnciLCJpc3MiOiJEZXZfbW9kZWxvX3JvbHMiLCJleHAiOjE2ODU0NTMyODV9.b6MbusjYOlsL1by9Jr8_6Y0w4ZLsfJqhYFcriJPO34E'
  useEffect(() => {
    fetch(
      "https://unit-trust-corporation-api.kindmushroom-705dfbe6.centralus.azurecontainerapps.io/api/users/1/demografic",{

        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            'Authorization': 'Bearer ' + token
      }
      }
    )   
        
      .then((response) => response.json()) // Parse response into JSON
      .then((responseData) => {
        setData(responseData); // Set the extracted data to the state variable
      })
      .catch((error) => {
        console.error("Error fetching demographic data:", error);
      });
  }, []);
  console.log("Data variable:", data);
  return (
    <div
      className="border border-black"
      style={{ background: "white" }}
    >
      <div className="row mt-3" style={{ verticalAlign: "middle" }}>
        <div className="col">
          <p className="fw-bold ms-2">{data.total}</p>
        </div>
        <div className="col d-flex justify-content-end me-3">
          <p>All accounts</p>
        </div>
      </div>
      <div
        id="container"
        className="bg-danger m-auto border rounded"
        // style={{ height: 152, width: 304 }}
      >
        <table
          className="table"
          style={{ fontSize: "12px", color: "white", border: 0 }}
        >
          <thead>
            <tr>
              <th scope="col">Age Range</th>
              <th scope="col">Gender</th>
              <th scope="col">Incoming Range</th>
            </tr>
          </thead>
          <tbody>
            {data.demograficRanges && data.demograficRanges.map((item, index) => (
            <tr key={index}>
              <td>{item.rangeAge}</td>
              <td>{item.gender}</td>
              <td>{item.rangeincome}</td>
            </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
export default Demographic;