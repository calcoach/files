'use client';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useEffect, useState } from 'react';
export const Geo= () => {
    const [data, setData] = useState([]);
    const [showList, setShowList] = useState(false); // Estado para controlar la visibilidad de la lista
   const token = 'eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiJqdWFuLnZpbGxhQGV4YW1wbGUuY29tIiwiaWF0IjoxNjg0ODQ4NDg1LCJzdWIiOiIkYXJnb24yaWQkdj0xOSRtPTEwMjQsdD0xLHA9MSQ0NTNFVUVPUHBGclYwQWQ2UXdpclJBJDNGVU10d3pGcDNmamdxTGhqVC9wcXk4a05vK0VMUTRWTFh5ck5jdFJwYnciLCJpc3MiOiJEZXZfbW9kZWxvX3JvbHMiLCJleHAiOjE2ODU0NTMyODV9.b6MbusjYOlsL1by9Jr8_6Y0w4ZLsfJqhYFcriJPO34E'
  useEffect(() => {
    fetch(
      "https://unit-trust-corporation-api.kindmushroom-705dfbe6.centralus.azurecontainerapps.io/api/users/1/geografic",{

        method: "GET",
        headers: {
            "Content-Type": "application/json",
            "Accept": "application/json",
            'Authorization': 'Bearer ' + token
      }
      }
    )   
        
      .then((response) => response.json()) // Parse response into JSON
      .then((responseData) => {
        setData(responseData); // Set the extracted data to the state variable
      })
      .catch((error) => {
        console.error("Error fetching Geografic data:", error);
      });
  }, []);
  console.log("Data variable:", data);
  
    const handleViewAll = () => {
    //  setShowList(true); // Mostrar la lista al hacer clic en el botón "View All"
    };
  
    return (
      <div className="container"style={{backgroundColor:'White'}}>
        <div className="row">
          <div className="col">
            <div className="d-flex justify-content-center align-items-center">
              <h1 className="me-3"></h1>
             
            </div>
          </div>
        </div>
      
          <div className="row">
            <div className="col">
              <div className="mx-auto" style={{backgroundColor:'White'}}>
                <ul className="list-group">
                  {data.map(item => (
                    <li  className="list-group-item d-flex justify-content-between align-items-start">
                      <div className="ms-2 me-auto">
                        <div className="fw-bold">{item.typeResidence}</div>
                      </div>
                      <span className="badge bg-primary rounded-pill text-white">{item.value}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
      
      </div>
    );
  };
  export default Geo;