import { MainLayout } from '@/components/layouts'
import Link from 'next/link'
import React, { useEffect, useState } from 'react';
import { Demographic } from '@/components/segmentation/Demographic'
import { Investment } from '@/components/segmentation/Investment'
import { Geo } from '@/components/segmentation/Geo'
import { Costumers } from '@/components/segmentation/Costumers'
import "bootstrap/dist/css/bootstrap.min.css";


export default function SegmentationPage() {
  return (
    <MainLayout title={'Teslo-Shop - Segmentation'} pageDescription={'Encuentra los mejores productos de Teslo aquí'}>


      <div className="container text-center">
        <div className="row">
          <div className="col-md-4">
            <div style={{ textAlign: "left" , width: '301px'}}>Demographic</div>
            <div id="componente1" style={{ backgroundColor: "White" }}>
              <Demographic />
            </div>
          </div>
          <div className="col-md-4">
            <div style={{ textAlign: "left" }}>Investment</div>
            <div id="componente2" style={{  backgroundColor: "White" }}>
              <Investment />
            </div>
          </div>
          <div className="col-md-4">
            <div className='container text-center'>
              <div className='row'>
                <div className='col-md-6'> <div style={{ textAlign: "left" }}>Geographic</div>
                </div>
                <div className='col-md-6'>  <button className="btn btn" style={{ width: '100px', height: '42px' }}>View All</button></div>
              
              </div>

            </div>
            <div id="componente3" style={{  backgroundColor: "White" }}>
              <Geo />
            </div>
          </div>
        </div>

        <div className="row">
          <div className="col-md-12">
            <div style={{ textAlign: "left" }}>My Costumers</div>
            <div id="componente4" style={{ backgroundColor: "White" }}>
              <Costumers />
            </div>
          </div>
        </div>
      </div>



    </MainLayout>
  )
}
