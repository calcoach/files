import { SimpleLayout } from '@/components/layouts/SimpleLayout'
import { useRouter } from 'next/router';
import Link from 'next/link'

import { useForm } from "react-hook-form";


export default function RegisterPage() {

  const { register, formState: { errors }, handleSubmit } = useForm();
  const router = useRouter();

  const onSubmit = async (data: any) => {

    const { first_name, last_name, email, gender, phone_number, address, password, conf_password } = data;
    if (password !== conf_password) {
      alert('Passwords do not match');
      return;
    }

    const API_URL = 'https://unit-trust-corporation-api.kindmushroom-705dfbe6.centralus.azurecontainerapps.io/api/usuarios';
    const request = await fetch(API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data)
    });

    const response = await request.json();

    if (response.user_id != null) {
      alert('Account created successfully');
      router.push('/');
    } else {
      alert('Account creation failed');
    }
  };


  return (
    <SimpleLayout title={'Teslo-Shop - Home'} pageDescription={'Encuentra los mejores productos de Teslo aquí'}>

      <div className="card o-hidden border-0 shadow-lg my-5">
        <div className="card-body p-0">

          {/* Nested Row within Card Body */}
          <div className="row">
            <div className="col-lg-5 d-none d-lg-block bg-register-image"></div>
            <div className="col-lg-7">
              <div className="p-5">
                <div className="text-center">
                  <h1 className="h4 text-gray-900 mb-4">Create an Account!</h1>
                </div>

                <form className="user" onSubmit={handleSubmit(onSubmit)}>

                  <div className="form-group row">
                    <div className="col-sm-6 mb-3 mb-sm-0">
                      <input type="text" className="form-control form-control-user" {...register("first_name", { required: true })} placeholder="First Name" />
                      {errors.first_name?.type === 'required' && <p role="alert" style={{ color: 'red' }} >This field is required</p>}
                    </div>
                    <div className="col-sm-6">
                      <input type="text" className="form-control form-control-user" {...register("last_name", { required: true })} placeholder="Last Name" />
                      {errors.last_name?.type === 'required' && <p role="alert" style={{ color: 'red' }} >This field is required</p>}
                    </div>
                  </div>

                  <div className="form-group">
                    <input type="email" className="form-control form-control-user" id="exampleInputEmail" placeholder="Email Address"
                      {...register("email", {
                        pattern: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                        required: true
                      }
                      )} />

                    {errors.email?.type === 'pattern' && <p role="alert" style={{ color: 'red' }} >The email address is invalid</p>}
                    {errors.email?.type === 'required' && <p role="alert" style={{ color: 'red' }} >This field is required</p>}

                  </div>

                  <div className="form-group row">
                    <div className="col-sm-6 mb-3 mb-sm-0">
                      <div className="select">
                        <select {...register("gender")}>
                          <option value="1">Male</option>
                          <option value="2">Female</option>
                          <option value="3">Rather not specify</option>
                        </select>
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <input type="text" className="form-control form-control-user" {...register("phone_number", { required: true })} placeholder="Phone Number" />
                      {errors.phone_number?.type === 'required' && <p role="alert" style={{ color: 'red' }} >This field is required</p>}
                    </div>
                  </div>

                  <div className="form-group">
                    <input type="text" className="form-control form-control-user" {...register("address", { required: true })} placeholder="Address" />
                    {errors.address?.type === 'required' && <p role="alert" style={{ color: 'red' }} >This field is required</p>}
                  </div>

                  <div className="form-group row">
                    <div className="col-sm-6 mb-3 mb-sm-0">
                      <input type="password" className="form-control form-control-user" {...register("password", { required: true })} placeholder="Password" />
                      {errors.password?.type === 'required' && <p role="alert" style={{ color: 'red' }} >This field is required</p>}
                    </div>
                    <div className="col-sm-6">
                      <input type="password" className="form-control form-control-user" {...register("conf_password", { required: true })} placeholder="Repeat Password" />
                      {errors.conf_password?.type === 'required' && <p role="alert" style={{ color: 'red' }} >This field is required</p>}
                    </div>
                  </div>

                  <input className="btn btn-primary btn-user btn-block" type="submit" value='Send' />

                </form>

                <hr />

                <div className="text-center">
                  <Link className="small" href="/">
                    Already have an account? Login!
                  </Link>

                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </SimpleLayout>
  )
}
