import { SimpleLayout } from '@/components/layouts/SimpleLayout'
import Image from 'next/image'
import Link from 'next/link'
import { useForm } from "react-hook-form";
import { useRouter } from 'next/router';

export default function LoginPage() {

  const { register, formState: { errors }, handleSubmit } = useForm();
  const router = useRouter();

  const onSubmit = async (data: any) => {
    
    console.log(data);
    try {
      const requestOptions = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      };
  
      const respuesta = await fetch('https://unit-trust-corporation-api.kindmushroom-705dfbe6.centralus.azurecontainerapps.io/api/login', requestOptions);
     // const datr = await respuesta.json();
     // console.log(datr);
  
      router.push('/segmentation');
    } catch (error) {
      alert("Alert error");
      console.log(error);
    }
   
    
  };

  return (

    <SimpleLayout title={'Teslo-Shop - Login'} pageDescription={'Encuentra los mejores productos de Teslo aquí'}>

      {/* Outer Row */}
      <div className="row justify-content-center">
        <div className="col-xl-10 col-lg-12 col-md-9">
          <div className="card o-hidden border-0 shadow-lg my-5">
            <div className="card-body p-0">

              {/* Nested Row within Card Body */}
              <div className="row">

                {/*<div className="col-lg-6 d-none d-lg-block bg-login-image">*/}
                <div className="col-lg-6 d-none d-lg-block">
                  <Image
                    width={452}
                    height={600}
                    quality={100}
                    src="/images/Bulb_Colored.jpg"
                    alt="Picture of the author" />
                </div>

                <div className="col-lg-6">
                  <div className="p-5">
                    <div className="text-center">
                      <h1 className="h4 text-gray-900 mb-4">Welcome Back!</h1>
                    </div>

                    <form className="user" onSubmit={handleSubmit(onSubmit)}>

                      <div className="form-group">
                        <input type="email" className="form-control form-control-user"
                          placeholder="Enter Email Address..."
                          {...register("email", {
                            pattern: /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
                            required: true
                          }
                          )} />

                        {errors.email?.type === 'pattern' && <p role="alert" style={{ color: 'red' }} >The email address is invalid</p>}
                        {errors.email?.type === 'required' && <p role="alert" style={{ color: 'red' }} >The email is required</p>}
                      </div>
                      <div className="form-group">
                        <input type="password" className="form-control form-control-user"
                          {...register("password", { required: true })} placeholder="Password" />
                        {errors.password?.type === 'required' && <p role="alert" style={{ color: 'red' }} >The password is required</p>}
                      </div>
                      {/*<a href="index.html" className="btn btn-primary btn-user btn-block">Login</a>*/}
                      <input className="btn btn-primary btn-user btn-block" type="submit" value='Accept' />

                      <hr />
                      <a href="#" className="btn btn-google btn-user btn-block">
                        <i className="fab fa-google fa-fw"></i> Login with Google
                      </a>
                      <a href="#" className="btn btn-facebook btn-user btn-block">
                        <i className="fab fa-facebook-f fa-fw"></i> Login with Facebook
                      </a>

                    </form>

                    <hr />
                    <div className="text-center">
                      <Link className="small" href="/">
                        Home
                      </Link>
                    </div>
                    <div className="text-center">
                      <Link className="small" href="/register">
                        Create an Account!
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </SimpleLayout>
  )
}
