// Bootstrap CSS
import "bootstrap/dist/css/bootstrap.css";


import '@/public/fontawesome-free/css/all.css'
import '@/styles/globals.css'


import type { AppProps } from 'next/app'

import { useEffect } from "react";
import { useRouter } from "next/router";

export default function App({ Component, pageProps }: AppProps) {

  const router = useRouter();

  useEffect(()=>{
    if (typeof document !== undefined) {
      console.log("entro en el render script");

      const script = document.createElement('script');
      script.src = "/js/unit-trust.js";      
      script.async = true;
      document.body.appendChild(script);

      const script2 = document.createElement('script');
      script2.src = "/js/mdb.min.js";      
      script2.async = true;
      document.body.appendChild(script2);
    }
  }, []);

  useEffect(() => {

    if (typeof document !== undefined) {
      
      require('bootstrap/dist/js/bootstrap');

      /*console.log("entro en el render script");
      const script = document.createElement('script');
      script.src = "/js/unit-trust.js";      
      script.async = true;
      document.body.appendChild(script);*/

    }

    /*
    typeof document !== undefined
      ? require('bootstrap/dist/js/bootstrap')
      : null;*/

  }, [router.events]);

  return <Component {...pageProps} />;

}
