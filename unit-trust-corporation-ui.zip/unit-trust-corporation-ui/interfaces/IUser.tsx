interface IUser {
  user_id: string,
  firs_name: string,
  last_name: string,
  email: string,
  phone_number: string,  
  profile_picture_url: string,  
  gender: number,
  password: string,
  confPassword: string,
  adress: string, birthdate: string  
}